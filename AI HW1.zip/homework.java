/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package homework;

/**
 *
 * @author CHAITANYA POTLURI
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

class TreePositions {

    public int row;
    public int col;
}

class LizardStack {

    public int row;
    public int col;
}

class UnsafePositions {

    public int row;
    public int col;
}

public class homework{

    public int[][] solution;
    int noOfLizards = 0;
    int noOfNodes = 0;
    int algorithm = 0;

    int updatableRow = -1;
    int updatableCol = -1;

    List<TreePositions> list = new ArrayList<TreePositions>();
    List<LizardStack> lizardStackList = new ArrayList<LizardStack>();
    List<UnsafePositions> unsafePositionsList = new ArrayList<UnsafePositions>();

    TreePositions treePositions = new TreePositions();
    LizardStack lizardStack = new LizardStack();
    UnsafePositions unsafePositions = new UnsafePositions();
    int delta=0;
    int temperature=0;
    public homework() {

        java.util.ArrayList al = new java.util.ArrayList<String>();
        ArrayList entireMatrixValues = new ArrayList<Integer>();
        File file = new File(System.getProperty("user.dir") + "/input.txt");
        BufferedReader b;
        try {
            b = new BufferedReader(new FileReader(file));
            String readLine = "";
            while ((readLine = b.readLine()) != null) {
                String line = readLine;
                al.add(line);
            }

            if (al.size() > 0) {
                String alg = (String) al.get(0);
                if (alg.equalsIgnoreCase("DFS")) {
                    algorithm = 2;
                }
                if (alg.equalsIgnoreCase("BFS")) {
                    algorithm = 1;
                }
                if (alg.equalsIgnoreCase("SA")) {
                    algorithm = 3;
                }
                noOfLizards = Integer.parseInt((String) al.get(2));
                noOfNodes = Integer.parseInt((String) al.get(1));

                solution = new int[noOfNodes][noOfNodes];

                for (int i = 3; i < al.size(); i++) {
                    String value = (String) al.get(i);
//                    String values[] = value.split("\\s+");
                    for (int j = 0; j < value.length(); j++) {
                        solution[i - 3][j] = Integer.parseInt(value.charAt(j) + "");
//                        solution[i - 3][j] = Integer.parseInt(values[j]);
                    }
                }
                getTreePositions(solution, noOfNodes);
                if(algorithm==1){
                         bFS();
                }else if(algorithm==2){
                          dFS();
                }else if(algorithm==3){
                    if(delta>=0 && temperature>=0){
                           sA();
                    }
                }
            }
        } catch (Exception ex) {
//            System.out.println("exception: " + ex.getMessage());
               writeDataToFile("FAIL","");
        }

    }


    /*
    Getting the positions of the trees in the nursery
     */
    public void getTreePositions(int[][] solution, int noOfNodes) {

        for (int row = 0; row < noOfNodes; row++) {
            for (int col = 0; col < noOfNodes; col++) {
                if (solution[row][col] == 2) {
//                   This Step is added
                    TreePositions treePositions = new TreePositions();
                    treePositions.row = row;
                    treePositions.col = col;
                    list.add(treePositions);
                }
            }
        }

    }

    /*
        Check whether it is the position of Tree
     */
    public boolean isOnPositionOfTree(int currentRow, int currentCol) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).row == currentRow && list.get(i).col == currentCol) {
                return true;
            }
        }

        return false;
    }

    /*
        Check whether it is the position of Lizard
     */
    public boolean isOnPositionOfLizard(int currentRow, int currentCol) {

        if (solution[currentRow][currentCol] == 1) {
            return true;
        }

        return false;
    }

    public void solutionMethod() {
        int flag = 0;
        for (int i = 0; i < noOfNodes; i++) {
            flag = 0;
            for (int j = 0; j < noOfNodes; j++) {

                if (lizardStackList.size() == noOfLizards) {
                        String result="";
                    for (int x = 0; x < noOfNodes; x++) {
                        for (int y = 0; y < noOfNodes; y++) {
//                            System.out.print(solution[x][y]);
                            result+=solution[x][y];
                        }
//                        System.out.print("\n");
                        result+="\r\n";
                    }
                    writeDataToFile(result,"");
                    System.exit(0);
                }

                if (isOnPositionOfTree(i, j)) {
                    solution[i][j] = 2;
                } else if (isOnPositionOfLizard(i, j)) {
                    solution[i][j] = 1;
                } else if (safeAsPerAnyLizardsPlaced(i, j)) {
                    flag = 1;
                    placeLizardIntoSolution(i, j);
                }
                if (flag == 0 && j == noOfNodes - 1 && lizardStackList.size() > 0) {
                    j = removeLizardFromSolution();
                    if (j == updatableCol) {
                        i = updatableRow;
                        j = updatableCol;
                    }
                }
            }

        }

        int resultLizardsCount = 0;
        int failFlag = 0;
        for (int x = 0; x < noOfNodes; x++) {
            for (int y = 0; y < noOfNodes; y++) {
                if (solution[x][y] == 1) {
                    resultLizardsCount++;
                }
            }

        }

        if (resultLizardsCount != 0 && resultLizardsCount < noOfLizards) {
            failFlag = 1;
//            System.out.print("FAIL");
            writeDataToFile("FAIL","");
        }

        if (failFlag == 0) {
           String result="";
            for (int x = 0; x < noOfNodes; x++) {
                for (int y = 0; y < noOfNodes; y++) {
//                    System.out.print(solution[x][y]);
                    result+=solution[x][y];
                }
//                System.out.print("\n");
                    result="\r\n";
            }
            writeDataToFile(result,"");
        }
    }
    /*
    Check with in the stack 
     */
    public boolean checkWithStack(int currentRow, int currentCol) {
        int[] result;
        int flag = 0;
        result = new int[lizardStackList.size()];

        for (int i = 0; i < lizardStackList.size(); i++) {

            result[i] = 0;
            if ((areLizardsPlacedDiagonal(lizardStackList.get(i).row, lizardStackList.get(i).col, currentRow, currentCol))
                    || (areLizardsAdjacent(lizardStackList.get(i).row, lizardStackList.get(i).col, currentRow, currentCol))) {
                result[i] = i;
                flag = 1;
            }

        }

        if (flag == 0) {
            return true;
        } else {

            for (int j = 0; j < result.length; j++) {
                for (int t = 0; t < list.size(); t++) {
                    if (treeExistsBetweenLizards(lizardStackList.get(j).row, lizardStackList.get(j).col, currentRow, currentCol, list.get(t).row, list.get(t).col)) {
                        return true;
                    }
                }
            }

        }

        return false;
    }

    /*
    Safe As per Any Lizards that are already placed
     */
    public boolean safeAsPerAnyLizardsPlaced(int currentRow, int currentCol) {
        int dummy = 1;
        if ((currentRow == 3) && currentCol == 7) {
            dummy = 0;
        }
        int flag = 1;
        int treeExists = 0;
        if (lizardStackList.size() > 0) {
            if (isOnPositionOfLizard(currentRow, currentCol) || isOnPositionOfTree(currentRow, currentCol)) {
                return false;
            } else {
                for (int i = lizardStackList.size(); i > 0; i--) {
                    
                    // checking for safer positions
                    if ((areLizardsAdjacentWithAbs(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol)) || (areLizardsPlacedDiagonal(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol)) || (areLizardsPlacedInSameRowCol(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol))) {
                        // check for rest of the conditions
                        if ((areLizardsAdjacentWithAbs(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol))) {
                            return false;
                        }
                        if ((areLizardAdjacentWhenRowColEqual(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol))) {
                            return false;
                        }
                      if ((areLizardsPlacedInSameRowCol(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol))) {
                            for (int t = 0; t < list.size(); t++) {
                                if (treeExistsBetweenLizards(lizardStackList.get(i - 1).row, lizardStackList.get(i - 1).col, currentRow, currentCol, list.get(t).row, list.get(t).col)) {
//                                    return decideLizardAndTreePosition(currentRow,currentCol);
                                    return treePositionsAndLizardPositions(currentRow,currentCol);
//                                    return true;
                                }
                            }
                            return false;
                        }
                        return false;
                    }
                }
//                if (treeExists == 1) {
//                    return true;
//                } else {
//                    return false;
//                }
            }
        }

        return true;
    }

//else{
//                        placeLizardIntoSolution(currentRow, currentCol);
//                    }

    /*
    Recursive function for tree check
     */
    public boolean treeCheck(int i,int currentRow,int currentCol){
//            boolean
            for (int k = i; k > 0; k--) { 
                        if ((areLizardsAdjacentWithAbs(lizardStackList.get(k - 1).row, lizardStackList.get(k - 1).col, currentRow, currentCol))) {
                            return false;
                        }
                        if ((areLizardAdjacentWhenRowColEqual(lizardStackList.get(k - 1).row, lizardStackList.get(k - 1).col, currentRow, currentCol))) {
                            return false;
                        }   
                        if ((areLizardsPlacedInSameRowCol(lizardStackList.get(k - 1).row, lizardStackList.get(k - 1).col, currentRow, currentCol))) {
                            for (int t = 0; t < list.size(); t++) {
                                if (treeExistsBetweenLizards(lizardStackList.get(k - 1).row, lizardStackList.get(k - 1).col, currentRow, currentCol, list.get(t).row, list.get(t).col)) {
//                                    treeCheck(k, currentRow, currentCol);
                                        
                                }
                            }             
                    }
                } 
         return true;
    }
    /*
    check whether lizard adjacent when row and col are equal
     */
    public boolean areLizardAdjacentWhenRowColEqual(int stackRow, int stackCol, int currentRow, int currentCol) {
        if (stackRow == currentRow) {
            if (stackCol + 1 == currentCol || stackCol - 1 == currentCol) {
                return true;
            }
        } else if (stackCol == currentCol) {
            if (stackRow + 1 == currentRow || stackRow - 1 == currentRow) {
                return true;
            }
        }
        return false;
    }

    /*
    check whether lizards are adjacent to each other
     */
    public boolean areLizardsAdjacent(int stackRow, int stackCol, int currentRow, int currentCol) {
//        if ((stackCol - currentCol) == 1 || (stackCol - currentCol) == -1)  {
        if (((stackCol - currentCol) == 1 && (stackRow - currentRow) == 1) || ((stackCol - currentCol) == -1 && (stackRow - currentRow) == -1)) {
//             || (stackRow - currentRow) == -1 || (stackRow - currentRow) == 1
            return true;
        }
        return false;
    }

    public boolean areLizardsAdjacentWithAbs(int stackRow, int stackCol, int currentRow, int currentCol) {
//        if ((stackCol - currentCol) == 1 || (stackCol - currentCol) == -1)  {
        if ((Math.abs(stackCol - currentCol) == 1 && Math.abs(stackRow - currentRow) == 1)) {
//             || (stackRow - currentRow) == -1 || (stackRow - currentRow) == 1
            return true;
        }
        return false;
    }

    /*
    Identify Unsafe Rows & colums of Two Lizards
     */
    public void identificationOfUnsafePositions(int stackRow, int stackCol) {
        if (unsafePositionsList.size() > 0) {
            unsafePositionsList.clear();
        }

        for (int i = 0; i < noOfNodes; i++) {
            for (int j = 0; j < noOfNodes; j++) {
                if (((stackCol - j) / (stackRow - i)) == -1 || ((stackCol - j) / (stackRow - i)) == 1) {
                    unsafePositions.row = i;
                    unsafePositions.col = j;

                    unsafePositionsList.add(unsafePositions);

                } else if (areLizardsPlacedInSameRowCol(i, j, stackRow, stackCol)) {
                    unsafePositions.row = i;
                    unsafePositions.col = j;

                    unsafePositionsList.add(unsafePositions);
                }
            }
        }

    }

    /*
        Tree Exists Between Lizards (vertically or Horizontally or Diagonally)
     */
    public boolean treeExistsBetweenLizards(int stackRow, int stackCol, int currentRow, int currentCol, int treeRow, int treeCol) {
        return between(stackRow, stackCol, treeRow, treeCol, currentRow, currentCol);
    }

    /*
    Between calculation function 
     */
    public boolean between(int x1, int y1, int lx, int ly, int x2, int y2) {
        return ((((x1 >= lx) && (lx >= x2)) || ((x1 <= lx) && (lx <= x2))) && (((y1 >= ly) && (ly >= y2)) || ((y1 <= ly) && (ly <= y2))));
    }

    /*
    Place Lizard into Stack and solution
     */
    public void placeLizardIntoSolution(int currentRow, int currentCol) {
        solution[currentRow][currentCol] = 1;
        lizardStack = new LizardStack();
        lizardStack.row = currentRow;
        lizardStack.col = currentCol;

        lizardStackList.add(lizardStack);

    }

    /*
    Pop up Lizard from stack and solution
     */
    public int removeLizardFromSolution() {

        int removableIndex = lizardStackList.size() - 1;

        int row = lizardStackList.get(removableIndex).row;
        int col = lizardStackList.get(removableIndex).col;

        updatableRow = row;
        updatableCol = col;

        solution[row][col] = 0;

        lizardStackList.remove(removableIndex);

        return col;

    }

    /*
    Check whether two lizards are in the same diagonal path
     */
    public boolean areLizardsPlacedDiagonal(int stackRow, int stackCol, int currentRow, int currentCol) {
        // Derived Formulae for placement of diagonal path is stackCol - currentCol / stackRow - currentRow is 1 or -1
        if ((stackRow - currentRow) != 0) {
            if (((stackCol - currentCol) / (stackRow - currentRow) == 1) || ((stackCol - currentCol) / (stackRow - currentRow) == -1)) {
                return true;
            }
        }
        return false;
    }

    /*
    Check whether two lizards are in the same row or column
     */
    public boolean areLizardsPlacedInSameRowCol(int stackRow, int stackCol, int currentRow, int currentCol) {
        if (stackRow == currentRow || stackCol == currentCol) {
            return true;
        }
        return false;
    }
    
      public static void writeDataToFile(String result, String alg) {
        try {
           String workingDir = System.getProperty("user.dir");
//	   System.out.println("Current working directory : " + workingDir);
            File statText = new File(workingDir+"/output.txt");
            statText.createNewFile();
            FileOutputStream is = new FileOutputStream(statText);
            OutputStreamWriter osw = new OutputStreamWriter(is);
            Writer w = new BufferedWriter(osw);
            if (result.equalsIgnoreCase("FAIL")) {
                w.write(result);
            } else {
                w.write("OK \r\n" + result);
            }
            w.close();
        } catch (Exception e) {
            writeDataToFile("FAIL", "");
        }
    }
      
     public boolean decideLizardAndTreePosition(int currentRow,int currentCol){
          int lflagRow=-1;  
          int tflagRow=-1;  
          int lflagCol=-1;  
          int tflagCol=-1;  
          boolean lflagStatus=false;
          boolean tflagStatus=false;
          
          for (int i = 0; i < noOfNodes; i++) {
              for (int j = 0; j < noOfNodes; j++) {
                    if(j==currentCol){
                            if(i==currentRow && j==currentCol){
                                break;
                            }
                            if(solution[i][j]==1){
                                lflagCol=j;
                            }  
                           if(solution[i][j]==2){
                                    tflagCol=j;
                            }
                    }
                    if(i==currentRow){
                            if(solution[i][j]==1){
                                lflagRow=i;
                            }  
                           if(solution[i][j]==2){
                                    tflagRow=i;
                            }
                    }
              }
         }
         if( (lflagCol>tflagCol)){
                lflagStatus=true;

                return false;
         }else{
                return true;
         } 
         
         
//          if( (lflagRow>tflagRow)){
//                lflagStatus=true;
//         }else{
//                tflagStatus=true;
//         } 
//         return false;
     } 
     
     public boolean treePositionsAndLizardPositions(int currentRow,int currentCol){
           int lflagRow=-1;  
          int tflagRow=-1;  
          int lflagCol=-1;  
          int tflagCol=-1;  
          boolean lflagStatus=false;
          boolean tflagStatus=false;
//          List<TreePositions> list = new ArrayList<TreePositions>();
//          List<LizardStack> lizardStackList = new ArrayList<LizardStack>();
          for (int i = 0; i < list.size(); i++) {
                int row=list.get(i).row;
                int col=list.get(i).col;
                if(row>=currentRow && col>=currentCol){
                    break;
                }
                if(col==currentCol){
                        tflagCol=col;
                }
         }
          
//          lizards
            for (int i = 0; i < lizardStackList.size(); i++) {
                
                int row=lizardStackList.get(i).row;
                int col=lizardStackList.get(i).col;
                if(areLizardsAdjacentWithAbs(row,col, currentRow, currentCol)){
                    return false;
                }
                if(row>=currentRow && col>=currentCol){
                    break;
                }
                if(col==currentCol){
                        lflagCol=col;
                }
         } 
          if( (lflagCol>tflagCol)){
                lflagStatus=true;

                return false;
         }else{
                return true;
         }
     } 
      
      public void bFS(){
          solutionMethod();
      }
      public void dFS(){
          solutionMethod();
      }
      public void sA(){
          solutionMethod();
      }

    public static void main(String[] args) {
        {
            homework hw= new homework();

        }
    }
}
