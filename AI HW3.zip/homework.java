/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package resolution;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author CHAITANYA POTLURI
 */
class Predicates {

    String predicateName;
    ArrayList<String> actualParameters;
    boolean isTrue;

    public Predicates(String predicateName, ArrayList<String> actualParameters, boolean isTrue) {
        this.predicateName = predicateName;
        this.actualParameters = actualParameters;
        this.isTrue = isTrue;
    }

    public Predicates(String predicateName) {
        this.predicateName = predicateName;
    }

    public Predicates(ArrayList<String> actualParameters) {
        this.actualParameters = actualParameters;
    }

    public Predicates(boolean isTrue) {
        this.isTrue = isTrue;
    }

    public Predicates(Predicates p) {
        predicateName = p.predicateName;
        actualParameters = new ArrayList<>(p.actualParameters);
        isTrue = p.isTrue;
    }

    public String negationOfPredicates() {
        String negatedPredicate = predicateName + actualParameters;

        if (!isTrue) {
            negatedPredicate = negatedPredicate.concat("~");
        }
        return negatedPredicate;
    }

}

public class homework {

    BufferedReader b;
    File file;

    private static Scanner input;
    BufferedWriter outputWriter = null;

    public static ArrayList<ArrayList<Predicates>> knowledgeBase = new ArrayList<>();
    public static Map<String, Set<Integer>> index = new HashMap<>();
    public static ArrayList<Predicates> queryList = new ArrayList<>();

    private static PrintWriter out;

    public homework() {

        try {

            file = new File(System.getProperty("user.dir") + "/input.txt");

            out = new PrintWriter(System.getProperty("user.dir") + "/output.txt");

            input = new Scanner(file);

            int queriesCount = input.nextInt();
            input.nextLine();
            for (int i = 0; i < queriesCount; i++) {

                String queryStr = input.nextLine();
                Predicates p = convertStringToPredicate(queryStr, 0);
                queryList.add(p);
            }

        } catch (Exception e) {
            out.print("Exception " + e.getMessage());
        }
    }
 
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        homework hw = new homework();
        
        
        int sameLineIndex = 0;

        int knowledgeBaseCount = input.nextInt();
        input.nextLine();
        for (int i = 0; i < knowledgeBaseCount; i++) {

            String str = compute(input.nextLine());
//            System.out.println(str);
            
            String[] sentences = str.split("\\&"); 
            for (String sentence : sentences) {
                ArrayList<Predicates> clause = new ArrayList<>();
                String[] predicates = sentence.split("\\|");
                for (String predicate : predicates) {
                    Predicates p = convertStringToPredicate(predicate, sameLineIndex);
                    String key = p.predicateName;
                    if (!p.isTrue) {
                        key = "~" + key;
                    }
                    if (!index.containsKey(key)) {
                        index.put(key, new HashSet<Integer>());
                    }
                    index.get(key).add(knowledgeBase.size());
                    clause.add(p);
                }
                knowledgeBase.add(clause);
            }
            sameLineIndex++;
        }

        for (int i = 0; i < queryList.size(); i++) {

            Predicates p = queryList.get(i);
            p.isTrue = !p.isTrue; 
            
            ArrayList<Predicates> negateQueryClause = new ArrayList<>();
            negateQueryClause.add(p);

            if (resolution(knowledgeBase, saveIndexs(index), negateQueryClause)) {
                out.println("TRUE");
                System.out.println("TRUE");
            } else {
                out.println("FALSE");
                System.out.println("FALSE");
            }
        }

        out.close();
    }

    private static String compute(String s) {
        String str = computeNestedNegation(s, 0);
        return distributeOr(str);
    }
    
    private static String computeNestedNegation(String clauseString, int index)
    {
        int id = 0;
        int count = 1;
        
        if(index >= clauseString.length()){
            return "";
        }
        
        if(index + 1 >= clauseString.length() || !clauseString.substring(index, index + 2).equalsIgnoreCase("(~"))
        {
            return clauseString.charAt(index) + computeNestedNegation(clauseString, index + 1);
        }
        
        id = index + 2;
        
        while (count > 0)
        {
            if(clauseString.charAt(id) == '(')
            {
                count++;
            }
            else if(clauseString.charAt(index) == ')')
            {
                count--;
            }
            id++;
        }
        
        return negate(clauseString.substring(index + 2, id - 1)) + computeNestedNegation(clauseString, id);
    }
    
    private static String negate(String s) {
        if (s.charAt(0) != '(') {
            return "(~" + s + ")"; 
        }
        if (s.substring(0, 2).equals("(~")) {
            if (s.substring(2, 4).equals("(~")) {
                return negate(s.substring(4, s.length() - 2));
            }
            return s.substring(2, s.length() - 1); 
        } 
        
        int idx = 1;
        if (s.charAt(idx++) == '(') {
            int count = 1;
            while (count > 0) {
                if (s.charAt(idx) == '(') {
                    count++;
                } else if (s.charAt(idx) == ')') {
                    count--;
                }
                idx++;
            }
        } else {
            while (s.charAt(idx) != ')') {
                idx++;
            }
            idx++;
        } 

        char operand;
        if (s.charAt(idx) == '|') {
            operand = '&';
        } else {
            operand = '|';
        }

        String first = negate(s.substring(1, idx));
        String second = negate(s.substring(idx + 1, s.length() - 1));
        return "(" + first + operand + second + ")";
    }
    
    
    private static boolean isVariable(String variable) {
        return Character.isLowerCase(variable.charAt(0));
    }
 

    private static String distributeOr(String s) { 

        if (s.charAt(1) == '~') {
            return s;
        }
        if (s.indexOf("&") == -1 || s.indexOf("|") == -1) {
            return s;
        }
        
        int idx = 1;
        if (s.charAt(idx++) == '(') {
            int count = 1;
            while (count > 0) {
                if (s.charAt(idx) == '(') {
                    count++;
                } else if (s.charAt(idx) == ')') {
                    count--;
                }
                idx++;
            }
        } else {
            while (s.charAt(idx) != ')') {
                idx++;
            }
            idx++;
        }

        String first = distributeOr(s.substring(1, idx)); 
        String second = distributeOr(s.substring(idx + 1, s.length() - 1)); 
        if (s.charAt(idx) == '&') {
            return '(' + first + '&' + second + ')';
        }
        
        if ((first.charAt(0) != '(' || first.charAt(1) == '~') && (second.charAt(0) != '(' || second.charAt(1) == '~')) {
            return s;
        }
        if (first.charAt(0) != '(' || first.charAt(1) == '~') {
           
            
            int idx2 = 1;
            if (second.charAt(idx2++) == '(') {
                int count2 = 1;
                while (count2 > 0) {
                    if (second.charAt(idx2) == '(') {
                        count2++;
                    } else if (second.charAt(idx2) == ')') {
                        count2--;
                    }
                    idx2++;
                }
            } else {
                while (second.charAt(idx2) != ')') {
                    idx2++;
                }
                idx2++;
            }

            String before = second.substring(1, idx2); 
            String after = second.substring(idx2 + 1, second.length() - 1); 
            return "(" + distributeOr("(" + first + "|" + before + ")") + "&" + distributeOr("(" + first + "|" + after + ")") + ")";
        }
        if (second.charAt(0) != '(' || second.charAt(1) == '~') { 
            int idx1 = 1;
            if (first.charAt(idx1++) == '(') {
                int count1 = 1;
                while (count1 > 0) {
                    if (first.charAt(idx1) == '(') {
                        count1++;
                    } else if (first.charAt(idx1) == ')') {
                        count1--;
                    }
                    idx1++;
                }
            } else {
                while (first.charAt(idx1) != ')') {
                    idx1++;
                }
                idx1++;
            }					

            String before = first.substring(1, idx1);
            String after = first.substring(idx1 + 1, first.length() - 1);
            return "(" + distributeOr("(" + before + "|" + second + ")") + "&" + distributeOr("(" + after + "|" + second + ")") + ")";
        }
        
        int idx1 = 1;
        if (first.charAt(idx1++) == '(') {
            int count1 = 1;
            while (count1 > 0) {
                if (first.charAt(idx1) == '(') {
                    count1++;
                } else if (first.charAt(idx1) == ')') {
                    count1--;
                }
                idx1++;
            }
        } else {
            while (first.charAt(idx1) != ')') {
                idx1++;
            }
            idx1++;
        }	

        String firstBefore = first.substring(1, idx1); // before&
        String firstAfter = first.substring(idx1 + 1, first.length() - 1);

        
        int idx2 = 1;
        if (second.charAt(idx2++) == '(') {
            int count2 = 1;
            while (count2 > 0) {
                if (second.charAt(idx2) == '(') {
                    count2++;
                } else if (second.charAt(idx2) == ')') {
                    count2--;
                }
                idx2++;
            }
        } else {
            while (second.charAt(idx2) != ')') {
                idx2++;
            }
            idx2++;
        }

        String secondBefore = second.substring(1, idx2); 
        String secondAfter = second.substring(idx2 + 1, second.length() - 1);

        return "(((" + distributeOr("(" + firstBefore + "|" + secondBefore + ")") + "&"
                + distributeOr("(" + firstBefore + "|" + secondAfter + ")") + ")" + "&"
                + distributeOr("(" + firstAfter + "|" + secondBefore + ")") + ")" + "&"
                + distributeOr("(" + firstAfter + "|" + secondAfter + ")") + ")";
    }


    private static boolean addClauseToKnowledgeBaseIfNotExists(ArrayList<ArrayList<Predicates>> knowledgeBase, Map<String, Set<Integer>> index, ArrayList<Predicates> clause) {

        for (ArrayList<Predicates> clauseInKB : knowledgeBase) {
           
            if (clauseInKB.toString().equals(clause.toString())) {
                return false;
            }
        }

        for (Predicates p : clause) {
            String key = p.predicateName;
            if (!p.isTrue) {
                key = "~" + key;
            }
            if (!index.containsKey(key)) {
                index.put(key, new HashSet<Integer>());
            }
            index.get(key).add(knowledgeBase.size());
        }
        knowledgeBase.add(clause);
        return true;
    }

    
    private static Predicates convertStringToPredicate(String givenString, int sameLineIndex) {

        boolean positive = true;
        int idx = 0;
        while (!Character.isLetter(givenString.charAt(idx))) {
            if (givenString.charAt(idx++) == '~') {
                positive = false;
            }
        }
        int nameStart = idx;
        while (givenString.charAt(idx) != '(') {
            idx++;
        }
        int pStart = idx;
        String name = givenString.substring(nameStart, pStart);

        while (givenString.charAt(idx) != ')') {
            idx++;
        }
        String argStr = givenString.substring(pStart + 1, idx).replaceAll(" ", "");
        String[] args = argStr.split(",");
        ArrayList<String> arguments = new ArrayList<>();
        for (String arg : args) {
            if (isVariable(arg)) {
                arg = arg + sameLineIndex;
            }
            arguments.add(arg);
        }
        return new Predicates(name, arguments, positive);
    }
    
    private static Map<String, Set<Integer>> saveIndexs(Map<String, Set<Integer>> indexes) {

        Map<String, Set<Integer>> copyIndexes = new HashMap<>();
        for (Map.Entry<String, Set<Integer>> entry : indexes.entrySet()) {
            Set<Integer> value = new HashSet<>();
            for (int i : entry.getValue()) {
                value.add(i);
            }
            copyIndexes.put(entry.getKey(), value);
        }
        return copyIndexes;
    }

    
    private static boolean resolution(ArrayList<ArrayList<Predicates>> knowledgeBase, Map<String, Set<Integer>> index, ArrayList<Predicates> clause) {

        long startTime = System.currentTimeMillis();

        ArrayList<ArrayList<Predicates>> queryList = new ArrayList<>();
        queryList.add(clause);

        while (!queryList.isEmpty()) {

            ArrayList<ArrayList<Predicates>> result = new ArrayList<>();

            for (ArrayList<Predicates> query : queryList) {

                for (int i = 0; i < query.size(); i++) { 
                    Predicates p = query.get(i);
                    String negKey = p.predicateName;
                    if (p.isTrue) {
                        negKey = "~" + negKey;
                    }

                    if ((System.currentTimeMillis() - startTime) / 1000 > 10) {
                        return false;
                    }

                    if (index.containsKey(negKey)) {
                        Set<Integer> idxInKB = index.get(negKey);
                        for (int idx : idxInKB) {
                            ArrayList<Predicates> resPredicate = knowledgeBase.get(idx);
                            for (int j = 0; j < resPredicate.size(); j++) { 

                                Map<String, String> deltaValue = new HashMap<>(); 
                                if ((deltaValue = sol(p, resPredicate.get(j), deltaValue)) != null) { 

                                    ArrayList<Predicates> newClause = new ArrayList<>();

                                    ArrayList<Predicates> queryCopy = cloneClause(query);
                                    queryCopy.remove(i);
                                    updateVariableWithAcutalValue(queryCopy, deltaValue);
                                    newClause.addAll(queryCopy);

                                    
                                    ArrayList<Predicates> palCopy = cloneClause(resPredicate);
                                    palCopy.remove(j);
                                    updateVariableWithAcutalValue(palCopy, deltaValue);
                                    newClause.addAll(palCopy);

                                    if (newClause.size() == 0) {
                                        return true;
                                    }
                                    result.add(newClause);
                                }
                            }
                        }
                    }
                }
            }

            boolean newBooleanValue = false;
            for (int i = 0; i < queryList.size(); i++) {
                ArrayList<Predicates> query = queryList.get(i);
               
                if (addClauseToKnowledgeBaseIfNotExists(knowledgeBase, index, query)) {
                    newBooleanValue = true;
                }
                
                if ((System.currentTimeMillis() - startTime) / 1000 > 10) {
                    return false;
                }
            }
            if (!newBooleanValue) {
                return false;
            }

            queryList = result;
        }

        return false;
    }
    
    
    private static Map<String, String> sol(Predicates a, Predicates b, Map<String, String> deltaValue) {
        if (deltaValue == null) {
            return null;
        }
        if ((!a.predicateName.equals(b.predicateName)) || (a.isTrue == b.isTrue)) {
            return null;
        }
        return differenceList(a.actualParameters, b.actualParameters, deltaValue);
    }
    
    
    private static Map<String, String> differenceList(List<String> list1, List<String> list2, Map<String, String> deltaValue) {
        if (deltaValue == null) {
            return null;
        }
        if (list1.size() != list2.size()) {
            return null;
        }

        String s1 = list1.get(0);
        String s2 = list2.get(0);

        if (list1.size() == 1 && list2.size() == 1) {
            return identicalVariables(s1, s2, deltaValue);
        }
        return differenceList(list1.subList(1, list1.size()), list2.subList(1, list2.size()), identicalVariables(s1, s2, deltaValue));
    }

    private static void updateVariableWithAcutalValue(ArrayList<Predicates> clause, Map<String, String> deltaValue) {

        for (Predicates p : clause) {
            ArrayList<String> arguments = p.actualParameters;
            for (int i = 0; i < arguments.size(); i++) {

                String key = arguments.get(i);
                if (deltaValue.containsKey(key)) {
                    arguments.set(i, deltaValue.get(key));
                }
            }
        }
    }

    private static ArrayList<Predicates> cloneClause(ArrayList<Predicates> clause) {
        ArrayList<Predicates> copy = new ArrayList<>();
        for (int i = 0; i < clause.size(); i++) {
            Predicates pCopy = new Predicates(clause.get(i));
            copy.add(pCopy);
        }
        return copy;
    }
    
    private static Map<String, String> identicalVariables(String s1, String s2, Map<String, String> deltaValue) {
        if (deltaValue == null) {
            return null;
        }

        if (deltaValue.containsKey(s1)) {
            s1 = deltaValue.get(s1);
        } else if (deltaValue.containsKey(s2)) {
            s2 = deltaValue.get(s2);
        } 

        if (!isVariable(s1) && !isVariable(s2)) { 
            if (!s1.equals(s2)) {
                return null;
            }
            return deltaValue;
        }

        if (!isVariable(s1)) {
            String tmp = s1;
            s1 = s2;
            s2 = tmp;
        } 

        deltaValue.put(s1, s2);
        return deltaValue;
    }

}
